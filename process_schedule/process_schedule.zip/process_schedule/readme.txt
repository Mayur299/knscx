

Dependencies:
- Python3.8
- Matplotlib
- g++ compiler




for fcfs run command:

./fcfs.sh "fcfsin.txt" "fcfsout.txt"           //fcfsin.txt is input test case file         fcfsout.txt is output file

input format is there in fcfsin.txt

-------------------------------------------------------------------------------------------------------------------------


for round robin run command:


./round_robin.sh "rrin.txt" "rrout.txt"      //rrin.txt is input test case file         rrout.txt is output file

input format is there in rrin.txt

---------------------------------------------------------------------------------------------------------------------------


for priority premptive run command:


./prior_prem.sh "prior.txt" "pout.txt"      //prior.txt is input test case file         pout.txt is output file

input format is there in prior.txt

-It works only for int type input



